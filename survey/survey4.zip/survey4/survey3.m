function myTrials=survey3(sub, test)

% if you want to test the script (run 5 trials in small screen):
%    myTrials=survey3(99, true) 

% for real subjects, run using subject number:
%    myTrials=survey3(01, false)

% To make the survey shorter, we're having each subject rate half of the
% sentences (25-35 minutes)


% sub=02;
% test=false;

Screen('Preference', 'SkipSyncTests', 2 ); %TODO uncomment. 
clc;

yaxis=320;
singleWord=true;
centerRed = 2.2; %if the red letter in the words is not center make this larger to go to the left (3,4,5) and smaller (1,0,-1,-2) to go to the right. 
if test
    text_size = 24;
    yaxis ='center';
else
    text_size = 50; 
    yaxis = 320;
end
trialDuration=6; 
pauseLastRun = 1; 
word_rate = .175;

KbReleaseWait(-1);
%% Data
% old
% load sentStim.mat %stimuli
% load sentences_for_survey.mat
%% Load stimuli from Python and Copy and paste to .txt then to excel to retain accents
% load sentences_for_survey_cleaned.mat 
% stimuli = usedSents';
% save('sentences_for_survey_accents.mat','selectedOrigIds','stimuli')
%%
load stimuli_survey3.mat
% save stimuli_survey3.mat 'stimuli' 'selectedOrigIds'

%% Show half the stimuli to each subject
if sub==01 | sub==03 | sub==05
    stimuli = stimuli(1:384);
    ids = selectedOrigIds(1:384);
elseif sub==02 | sub==04 | sub==06
    stimuli = stimuli(385:end);
    ids = selectedOrigIds(385:end);
end
%%
if test
    stimuli = stimuli(20:24);
    ids = selectedOrigIds(20:24);
    % stimuli= {'Questa versione � pi� citt� l�'};
end

numTrials=length(stimuli);

%Text
for k=1:numTrials
    myTrials(k).sentence=stimuli(k);
    myTrials(k).id=k;
    myTrials(k).originalID=ids(k);
end

myTrials=Shuffle(myTrials);% randomise


%% Experiment
if test
    [win,screenRect]=Screen('OpenWindow',0,[127 127 127],[0 0 640 480]); %Open up a PTB window
else
    [win,screenRect]=Screen('OpenWindow',0,[127 127 127]);%[0 0 640 480]); %Open up a PTB window
end
xCent=round(screenRect(3)/2);%-round(screenRect(3)/10);
yCent=round(screenRect(4)/2);
HideCursor() 

%% Instructions
Screen('TextFont',win, 'Lucida Console');
Screen('TextSize',win, text_size);

mytext = 'Read each sentence and rate it from 1 to 5 on how hard it is to understand, where 1=not hard at all and 5=very hard. There is no right and wrong answer. You will have 5 seconds per sentence, so please answer with your first intuition.\n\nPress any key to begin';

% here
[nx, ny, bbox] = DrawFormattedText(win, mytext, 'center', yaxis,[],50);

Screen(win,'flip')
% KbWait([],2);
KbWait(-1);
KbReleaseWait(-1);

Screen(win,'flip')
%% Show stimuli
pause(2);
%%
fakeScannerPulse=GetSecs;

for k=4:numTrials
    myTrials(k).wait_start=GetSecs-fakeScannerPulse;
    if k==1
        while GetSecs<fakeScannerPulse+(trialDuration*(k-1))
        end
    end
    myTrials(k).trial_sent_start=GetSecs-fakeScannerPulse;
    sentence=myTrials(k).sentence{1};
    wordInd=[1 strfind(myTrials(k).sentence{1}, ' ')+1];
    word=[];
    cc=0;
    for ii=1:length(wordInd)-1
        cc=cc+1;
        word{cc}=sentence(wordInd(ii):wordInd(ii+1)-2);
    end
    word{end+1}=sentence(wordInd(end):end);
    % show sentences word by word
    if singleWord
        for ii=1:length(word)
            thisWord=word{ii};
%             if strfind(thisWord,'.')% fix full stop
%                 thisWord(strfind(thisWord,'.'))=[];
%             end
            tL=length(thisWord);
            if tL== 1
                targL=1;
            elseif tL< 5
                targL=2;
            elseif tL< 9
                targL=3;
            elseif tL<14
                targL=4;
            else
                targL=5;
            end
            Screen('TextFont',win,'Arial')
            Screen('TextSize',win,text_size)
            % fix apostrophes
            if strfind(thisWord,'''')
                targL=targL+length(strfind(thisWord,''''));
                while strcmp(thisWord(targL),'''')
                    targL=targL-1;
                end
            end
            if targL==1
                %         [nx, ny, textboundsTarg] = DrawFormattedText(win, thisWord, xCent-offSet, round(myScreen(4)/2), [0 0 0])
                [nx, ny, textboundsTarg] = DrawFormattedText(win, thisWord(targL), xCent, yCent, [255, 0, 0]);
            else
                [nx, ny, textboundsTarg] = DrawFormattedText(win, thisWord(1:targL-1), xCent+5000, yCent, [127, 127, 127]);
                offSet=textboundsTarg(3)-textboundsTarg(1);
                [nx, ny, textboundsTarg] = DrawFormattedText(win, thisWord, xCent-offSet, yCent, [0 0 0]);
                [nx, ny, textboundsTarg] = DrawFormattedText(win, thisWord(targL), xCent-centerRed, yCent, [255, 0, 0]);
            end
            Screen(win,'Flip')
            WaitSecs(word_rate) %eg, 0.15 (150 miliseconds per word)
        end
    else
        DrawFormattedText(win,myTrials(k).sentence{1},xCent,yCent, [0,0,0], 50);
        Screen(win,'flip')
        pause(3.5)
    end
    DrawFormattedText(win,'+',xCent,yCent,  [255,0,0]);
    Screen(win,'flip')
    %     myTrials(k).sent_end=GetSecs-fakeScannerPulse;
    %	Collect response
    keyPressed = 0;
    start = GetSecs;
    while GetSecs < start+trialDuration%5 seconds
        [keyPressed keyTime keyCode]=KbCheck;%TODO check
        if keyPressed
            disp('pressed')
            keyName=KbName(keyCode);
                        if strcmp(keyName,'Return')
                            DrawFormattedText(win,'pause','center',yaxis)
                            Screen(win,'Flip')
                            KbWait([],2)
                            if singleWord
                                for ii=1:length(word)
                                    thisWord=word{ii};
%                                     if strfind(thisWord,'.')% fix full stop
%                                         thisWord(strfind(thisWord,'.'))=[];
%                                     end
                                    tL=length(thisWord);
                                    if tL== 1
                                        targL=1;
                                    elseif tL< 5
                                        targL=2;
                                    elseif tL< 9
                                        targL=3;
                                    elseif tL<14
                                        targL=4;
                                    else
                                        targL=5;
                                    end
                                    Screen('TextFont',win,'Arial')
                                    Screen('TextSize',win,text_size)
                                    % fix apostrophes
                                    if strfind(thisWord,'''')
                                        targL=targL+length(strfind(thisWord,''''));
                                        while strcmp(thisWord(targL),'''')
                                            targL=targL-1;
                                        end
                                    end
                                    if targL==1
                                        %         [nx, ny, textboundsTarg] = DrawFormattedText(win, thisWord, xCent-offSet, round(myScreen(4)/2), [0 0 0])
                                        [nx, ny, textboundsTarg] = DrawFormattedText(win, thisWord(targL), xCent, yCent, [255, 0, 0]);
                                    else
                                        [nx, ny, textboundsTarg] = DrawFormattedText(win, thisWord(1:targL-1), xCent+5000, yCent, [127, 127, 127]);
                                        offSet=textboundsTarg(3)-textboundsTarg(1);
                                        [nx, ny, textboundsTarg] = DrawFormattedText(win, thisWord, xCent-offSet, yCent, [0 0 0]);
                                        [nx, ny, textboundsTarg] = DrawFormattedText(win, thisWord(targL), xCent-centerRed, yCent, [255, 0, 0]);
                                    end
                                    Screen(win,'Flip')
                                    WaitSecs(word_rate) %eg, 0.15 (150 miliseconds per word)
                                end
                            else
                                DrawFormattedText(win,myTrials(k).sentence{1},xCent,yCent, [0,0,0], 50);
                                Screen(win,'flip')
                                pause(3.5)
                            end
                            DrawFormattedText(win,'+',xCent,yCent,  [255,0,0]);
                            Screen(win,'flip')
                            start = GetSecs;
                        else
                            myTrials(k).Resp=(keyName(1));
                            break
                        end
        end
    end
    myRT_text = GetSecs-start;
    KbReleaseWait(-1)
    myTrials(k).RT=myRT_text;
    Screen(win,'flip')
    pause(1)
    if mod(k,10)==0
       save (['output_s' num2str(sub) '.mat']);
   end
end
DrawFormattedText(win,'The end','center',yaxis)
Screen(win,'Flip')
WaitSecs(2); %ITI
sca

%% Save

% answers = cell2mat(struct2cell(myTrials));
% saveName=['output_s' num2str(sub) '.csv'];
save (['output_s' num2str(sub) '.mat']);
% struct2csv(answers,strcat('/Users/danielmlow/Dropbox/cnn/experiment/presentation/',saveName))
% csvwrite(strcat('/Users/danielmlow/Dropbox/cnn/experiment/presentation/',saveName),answers);






end



