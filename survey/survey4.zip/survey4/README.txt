
We are running a survey where subjects rate each sentence from 1 to 5 on how easy it is to understand the sentence (the same one you did). We're trying to filter out weird sentences for our experiment.

Sometimes the script will return an error when run. Ignore and just run again and it should work. 

How to run: 
myTrials=survey3(sub, test) 
	where sub= subject number (01,02,etc) 
	and 
	test=true or false. 


The script chooses the stimuli depending on the subject number, so use 01,02,03,04,05,06. for our 6 subjects. 

To test the script for yourself (to see output), run:
	myTrials=survey3(99, true)
This will run 5 trials. 

To run final script, run in command line:
	before each run, do a clear all
	myTrials=survey3(01, false)

By running on full screen (myTrials=survey3(01,false), you can adjust position of red letter in line 16: centerRed = 1.5
centerRed = 1.5; %if the red letter in the words is not centered make this number larger to go to the left (3.1,4.,5., e.g., 3.8 or 3.0) and smaller (1.0,0.0, -1.0 ,-2.0) to go to the right. 1.5 was perfect on my computer full screen. 

You can pause at any time by pressing Enter. When pressing Enter again, it will continue from the previous trial. This is good for breaks or if the person missed the sentence, he/she can review it. 

Instructions (in Italian):

'Read each sentence and rate it from 1 to 5 on how easy it is to understand, where 1=very hard and 5=very easy. There is no right and wrong answer. You will have 5 seconds per sentence, so please answer with your first intuition. If there is something weird about the sentence, just give it a worse score. 


Then remind the subject that 1 is very hard and 5 is very easy. Remind them about the Enter pause button if they want to take a break or they missed a sentence. 


If you're not getting that red text after each pause, after about 5 minutes maybe ask them to pause by pressing Enter and see if they have any questions. 
If they can't read the sentences, because they're too fast you can make it a bit slower (0.20)  on line 26: word_rate = .175;

change sub parameter for every subject: 
myTrials=survey3(01,false)
myTrials=survey3(02,false)
myTrials=survey3(03,false)
myTrials=survey3(04,false)